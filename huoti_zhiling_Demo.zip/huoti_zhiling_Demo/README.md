   
(使用说明)
------------------

在本 agzhiling-sdk 文件夹中



(开启摄像头)
 --------------
 
    protected void onCreate(Bundle savedInstanceState)
    {
      
            @Override
            public void onClick(View v)
            {
                int rc = ActivityCompat.checkSelfPermission(mContext, Manifest.permission.CAMERA);
                if (rc == PackageManager.PERMISSION_GRANTED) {
                    Intent intent = new Intent(mContext, FaceDetectRGBActivity.class);
                    //startActivity(intent);
                    startActivityForResult(intent, 1101);
                } else {
                    requestCameraPermission(RC_HANDLE_CAMERA_PERM_RGB);
                }
            }
        });
		
        
		//获取当前版本信息
		
        String strversion = AgFace.GetVersion();
        TextView tText = (TextView) findViewById(R.id.textVersion);
        tText.setText(strversion);

    }
	
	
	(接口返回)
	-----------------------
	
    @Override
    protected void onActivityResult(int requestCode, int resultCode,  Intent data)
    {
        super.onActivityResult(requestCode, resultCode, data);

        boolean iRes = AgFace.GetFaceReal();
        String strV = ((iRes==true)?"真人 |":"非真人 |");
        strV+=AgFace.GetFaledInfo();

        String strTmp = AgFace.GetCapStrBase64();
        AlertDialog alertDialog2 = new AlertDialog.Builder(this)
                .setTitle(strV + " |文件长度  "+String.valueOf(strTmp.length()))//标题
                .setMessage(strTmp.length()>0?strTmp.substring(0,60):"")//内容
                .setIcon(m.tri.facedetectcamera.R.mipmap.ic_launcher)//图标
                .create();
        alertDialog2.show();
    }


(底层依赖项目)
---------------

https://git.agilestar.cn/sunli/huoti_zhiling_so
