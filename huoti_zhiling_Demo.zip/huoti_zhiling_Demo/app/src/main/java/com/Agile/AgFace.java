package com.Agile;

import android.util.Log;

public class AgFace
{
	
	   static {
           System.loadLibrary("AgileFM");
           mFaceRect = new float[200];
           mFaceMarks = new float[212];
           mFaceStates = new int[12];
           Log.i("MYINFO","loaded ok");
           mBReal = false;
           mStrBase64 = "";
    }

    private static String mStrBase64;
    private static Boolean mBReal;
    private static String mFailedInfo;

    public  static void SetFailedInfo(String failedinfo){mFailedInfo = failedinfo;};
    public  static String GetFaledInfo(){return mFailedInfo;}

    public  static String GetCapStrBase64(){return mStrBase64;}
    public  static void SetCapStrBase64(String base64){mStrBase64=base64;}

    public static void SetFaceReal(boolean bReal){mBReal=bReal;};
    public static Boolean  GetFaceReal(){return mBReal;}

    public static float[] mFaceRect;
    public static float[] mFaceMarks;
    public static int[] mFaceStates;
    //使用之前说明，要把模型文件，从assets 里面放到指定位置
    //加载模型 load so文件
    //Init初始化
    //使用，建议使用nv21格式的图像

   /*
    *
    *      初始化模板路径
    *      modelpath 模板路径
    *      pwd 密钥暂时为空；当前采用so绑定capplicationid的方式
    *      返回值 1 授权成功；0，时间限制的授权；-1 授权失败
    * */
    public static native int Init(String modelpath,String pwd);

    public static native String GetVersion();


     /**
 *  检测输入Nv12的格式图像，输出人脸信息
 *    buf 灰度数据，w宽，h高
 *
 *    mFaceStates[0]  1向左偏转 0无；
 *    mFaceStates[1]  1 向右偏转 否则，无 ；
 *    mFaceStates[2] 1 抬头 ，否则，无；
 *    mFaceStates[3]  1 低头，否则不低头
 *    mFaceStates[4]   1张嘴，0闭嘴 ；
 *    mFaceStates[5]  1 闭眼 0 无
 *    mFaceStates [6]  iso此选项无用 //当前图片数据需要如何旋转 1 逆时针90，2 顺时针90，3 垂直水平翻
 *    mFaceStates [7]  绕x轴旋转的角度
 *    mFaceStates [8]  绕y轴旋转的角度
 *    mFaceStates [9]  1 是活体 0 不是活体 (静默活体判断)
 *     mFaceStates [10] 1 戴口罩 0 不戴口罩
      *     *
 *   mFaceRect  float[]输出人脸框，0--3   左点，上点，右点，下点
 *   mFaceRect[4] 返回当前人脸的静默活体分值 0-1 值越大人脸越为真，反之越假     建议大于0.55 为活体
*    mFaceRect[5] 返回人眼张开程度，值越大张开的越大
*    mFaceRect[7] 绕x轴旋转的角度
 *   mFaceRect[8] 绕y轴旋转的角度
 *   mFaceMarks 当前废弃；输出68个关键点 0-1
 *
 *
 */
    public static native int FaceTraceNv12(byte[] buf, int w, int h,int[] faceState,float[] faceRect,float[] faceMarks);
    public static  int FaceTraceNv12Short(byte[] buf, int w, int h)
    {
        return FaceTraceNv12(buf,  w,  h, mFaceStates, mFaceRect,mFaceMarks);
    }
       /**
 *  检测输入 buf 为RGBA8888格式的数据的格式图像，输出人脸信息
 *    buf 灰度数据，w宽，h高
 *
 *    faceState[0]  1向左偏转 0无；
 *    faceState[1]  1 向右偏转 否则，无 ；
 *    faceState[2] 1 抬头 ，否则，无；
 *        faceState[3]  1 低头，否则不低头
 *        faceState[4]   1张嘴，0闭嘴 ；f
 *        aceState[5]  1 眨眼 0 无
 *
 *
 *   faceRect 输出人脸框，0--1   左点，上点，右点，下点
 *
 *   faceMarks输出68个关键点 0-1
 *
 *
 *   返回值：0 代表没有人脸返回，1 代表有人脸返回
* */
 public static native int FaceTraceRGBA8888(int[] buf, int w, int h,int[] faceState,float[] faceRect,float[] faceMarks);
}