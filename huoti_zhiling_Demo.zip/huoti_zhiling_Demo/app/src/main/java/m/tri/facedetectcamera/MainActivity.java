package m.tri.facedetectcamera;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.os.Environment;
import android.support.v7.app.AppCompatActivity;
import android.support.v4.app.ActivityCompat;

import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.Agile.AgFace;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;


import m.tri.facedetectcamera.activity.FaceDetectRGBActivity;

/**
 * Created by Nguyen on 5/20/2016.
 */

public class MainActivity extends AppCompatActivity {

    public static final String TAG = MainActivity.class.getSimpleName();

    private static final int RC_HANDLE_CAMERA_PERM_RGB = 1;


    private Context mContext;
    private byte[] InputStreamToByte(InputStream is) throws IOException
    {
        ByteArrayOutputStream bytestream = new ByteArrayOutputStream();
        int ch;
        while ((ch = is.read()) != -1) {
            bytestream.write(ch);
        }
        byte imgdata[] = bytestream.toByteArray();
        bytestream.close();
        return imgdata;
    }
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mContext = this;

        Button btnCameraRGB = (Button) findViewById(R.id.btnRGB);
        btnCameraRGB.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v)
            {
                int rc = ActivityCompat.checkSelfPermission(mContext, Manifest.permission.CAMERA);
                if (rc == PackageManager.PERMISSION_GRANTED) {
                    Intent intent = new Intent(mContext, FaceDetectRGBActivity.class);
                    //startActivity(intent);
                    startActivityForResult(intent, 1101);
                } else {
                    requestCameraPermission(RC_HANDLE_CAMERA_PERM_RGB);
                }
            }
        });

        String strversion = AgFace.GetVersion();
        TextView tText = (TextView) findViewById(R.id.textVersion);
        tText.setText(strversion);

        DoInitAgFace();

    }
    @Override
    protected void onActivityResult(int requestCode, int resultCode,  Intent data)
    {
        super.onActivityResult(requestCode, resultCode, data);

        boolean iRes = AgFace.GetFaceReal();
        String strV = ((iRes==true)?"真人 |":"非真人 |");
        strV+=AgFace.GetFaledInfo();

        String strTmp = AgFace.GetCapStrBase64();
        AlertDialog alertDialog2 = new AlertDialog.Builder(this)
                .setTitle(strV + " |文件长度  "+String.valueOf(strTmp.length()))//标题
                .setMessage(strTmp.length()>0?strTmp.substring(0,60):"")//内容
                .setIcon(m.tri.facedetectcamera.R.mipmap.ic_launcher)//图标
                .create();
        alertDialog2.show();
    }


    public  void DoInitAgFace()
    {
        String state= Environment.getExternalStorageState();
        if(Environment.MEDIA_MOUNTED.equals(state))
        {

            verifyStoragePermissions(this);

            String DATABASE_PATH = android.os.Environment.getExternalStorageDirectory().getAbsolutePath();
            Log.i(TAG, "DATABASE_PATH");
            String newPath = DATABASE_PATH+"/detection";
            CopyAssets(this,"detection",newPath);

            newPath = DATABASE_PATH+"/model_smallface";
            CopyAssets(this,"model_smallface",newPath);


        }

        //SD卡的绝对路径
        int iInit = AgFace.Init( android.os.Environment.getExternalStorageDirectory().getAbsolutePath(),"");

        if(iInit == -1)
        {
            AlertDialog alertDialog1 = new AlertDialog.Builder(this)
                    .setTitle("WARNING")//标题
                    .setMessage("当前授权不可用")//内容
                    .setIcon(R.mipmap.ic_launcher)//图标
                    .create();
            alertDialog1.show();

        }
        else if(iInit == 0)
        {
            //时间授权内
        }
        else if(iInit == 1)
        {
            //永久授权
        }
    }
    private static final int REQUEST_EXTERNAL_STORAGE = 1;
    private static String[] PERMISSIONS_STORAGE =
    {
            Manifest.permission.READ_EXTERNAL_STORAGE,
            Manifest.permission.WRITE_EXTERNAL_STORAGE,
            Manifest.permission.MOUNT_UNMOUNT_FILESYSTEMS
    };
/**

 */
    public static void verifyStoragePermissions(Activity activity) {
        //
        int permission = ActivityCompat.checkSelfPermission(activity, Manifest.permission.WRITE_EXTERNAL_STORAGE);

        if (permission != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(activity, PERMISSIONS_STORAGE, REQUEST_EXTERNAL_STORAGE);

        }
    }
    /**
     * 复制asset文件到指定目录
     * @param oldPath  asset下的路径
     * @param newPath  SD卡下保存路径
     */
    public  void CopyAssets(Context context, String oldPath, String newPath) {
        try {
            String fileNames[] = this.getAssets().list(oldPath);// 获取assets目录下的所有文件及目录名
            String fileassert = this.getAssets().toString();
            if (fileNames.length > 0) {// 如果是目录
                File file = new File(newPath);
                file.mkdirs();// 如果文件夹不存在，则递归
                for (String fileName : fileNames) {

                    CopyAssets(context, oldPath + "/" + fileName, newPath + "/" + fileName);
                }
            } else {// 如果是文件
                InputStream is = context.getAssets().open(oldPath);
                FileOutputStream fos = new FileOutputStream(new File(newPath));
                byte[] buffer = new byte[1024];
                int byteCount = 0;
                while ((byteCount = is.read(buffer)) != -1) {// 循环从输入流读取
                    // buffer字节

                    fos.write(buffer, 0, byteCount);// 将读取的输入流写入到输出流
                }
                fos.flush();// 刷新缓冲区
                is.close();
                fos.close();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }



    private void requestCameraPermission(final int RC_HANDLE_CAMERA_PERM) {
        Log.w(TAG, "Camera permission is not granted. Requesting permission");

        final String[] permissions = new String[]{Manifest.permission.CAMERA};

        ActivityCompat.requestPermissions(this, permissions, RC_HANDLE_CAMERA_PERM);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {

        if (grantResults.length != 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED && requestCode == RC_HANDLE_CAMERA_PERM_RGB)
        {
            Intent intent = new Intent(mContext, FaceDetectRGBActivity.class);
            startActivity(intent);
            return;
        }


        Log.e(TAG, "Permission not granted: results len = " + grantResults.length +
                " Result code = " + (grantResults.length > 0 ? grantResults[0] : "(empty)"));
    }

}
