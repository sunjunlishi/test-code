package m.tri.facedetectcamera.activity;



import android.app.AlertDialog;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.ImageFormat;
import android.graphics.Matrix;
import android.hardware.Camera;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;

import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.ViewGroup;
import android.view.WindowManager;

import com.Agile.AgFace;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.List;

import m.tri.facedetectcamera.R;
import m.tri.facedetectcamera.activity.ui.FaceOverlayView;
import m.tri.facedetectcamera.model.FaceResult;
import m.tri.facedetectcamera.utils.CameraErrorCallback;
import m.tri.facedetectcamera.utils.Util;
import m.tri.facedetectcamera.activity.NV21ToBitmap;

import static java.lang.Math.abs;


/**
 * Created by Nguyen on 5/20/2016.
 */

/**
 * FACE DETECT EVERY FRAME WIL CONVERT TO RGB BITMAP SO THIS HAS LOWER PERFORMANCE THAN GRAY BITMAP
 * COMPARE FPS (DETECT FRAME PER SECOND) OF 2 METHODs FOR MORE DETAIL
 */


public final class FaceDetectRGBActivity extends AppCompatActivity implements SurfaceHolder.Callback, Camera.PreviewCallback {

    // Number of Cameras in device.
    private int numberOfCameras;

    public static final String TAG = FaceDetectRGBActivity.class.getSimpleName();

    private Camera mCamera;
    private int cameraId = 1;

    // Let's keep track of the display rotation and orientation also:
    private int mDisplayRotation;
    private int mDisplayOrientation;

    private int previewWidth;
    private int previewHeight;

    // The surface view for the camera data
    private SurfaceView mView;

    // Draw rectangles and other fancy stuff:
    private FaceOverlayView mFaceView;

    // Log all errors:
    private final CameraErrorCallback mErrorCallback = new CameraErrorCallback();

    private boolean isThreadWorking = false;
    private Handler handler;
    private FaceDetectThread detectThread = null;
    private int prevSettingWidth;
    private int prevSettingHeight;
    private int mRealCount = 0;
    public Bitmap mNewSaveBitmap=null;
    private FaceResult face;


    private  NV21ToBitmap mNv212Bitmap;
    private String BUNDLE_CAMERA_ID = "camera";
    public boolean mBneedCap =false;

   public static FaceDetectRGBActivity  gSFaceActivity=null;

    //==============================================================================================
    // Activity Methods
    //==============================================================================================

    /**
     * Initializes the UI and initiates the creation of a face detector.
     */
    @Override
    public void onCreate(Bundle icicle) {
        super.onCreate(icicle);

        setContentView(R.layout.activity_camera_viewer);

        mView = (SurfaceView) findViewById(R.id.surfaceview);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

        // Now create the OverlayView:
        mFaceView = new FaceOverlayView(this);
        addContentView(mFaceView, new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        gSFaceActivity = this;
        handler = new Handler();

        face = new FaceResult();


        mNv212Bitmap = new NV21ToBitmap(this);
        getSupportActionBar().setDisplayShowTitleEnabled(true);
        getSupportActionBar().setHomeButtonEnabled(true);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setTitle("Face Detect RGB");

        if (icicle != null)
            cameraId = icicle.getInt(BUNDLE_CAMERA_ID, 1);

        mBneedCap = true;

        AgFace.SetFaceReal(false);
        AgFace.SetCapStrBase64("");
        AgFace.SetFailedInfo("成功");
        mRealCount = 0;

    }


    @Override
    protected void onPostCreate(Bundle savedInstanceState) {
        super.onPostCreate(savedInstanceState);
        // Check for the camera permission before accessing the camera.  If the
        // permission is not granted yet, request permission.
        SurfaceHolder holder = mView.getHolder();
        holder.addCallback(this);
        holder.setFormat(ImageFormat.NV21);
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu_camera, menu);

        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        switch (item.getItemId()) {
            case android.R.id.home:
                super.onBackPressed();
                return true;

            case R.id.switchCam:

                if (numberOfCameras == 1) {
                    AlertDialog.Builder builder = new AlertDialog.Builder(this);
                    builder.setTitle("Switch Camera").setMessage("Your device have one camera").setNeutralButton("Close", null);
                    AlertDialog alert = builder.create();
                    alert.show();
                    return true;
                }

                cameraId = (cameraId + 1) % numberOfCameras;
                recreate();

                return true;


            default:
                return super.onOptionsItemSelected(item);
        }
    }

    /**
     * Restarts the camera.
     */
    @Override
    protected void onResume() {
        super.onResume();

        Log.i(TAG, "onResume");
        startPreview();
    }

    /**
     * Stops the camera.
     */
    @Override
    protected void onPause() {
        super.onPause();
        Log.i(TAG, "onPause");
        if (mCamera != null) {
            mCamera.stopPreview();
        }
    }

    int minR = 1000;
    float maxDisEye = 0;
    public void CapToBitmap(byte[] data)
    {

        if(mBneedCap)
        {
            Bitmap mBitmap = mNv212Bitmap.nv21ToBitmap(data, previewWidth, previewHeight);
            int nR = abs(AgFace.mFaceStates[7])+abs(AgFace.mFaceStates[8]);//旋转角度，值越小，越是正脸
            float fDisEye = AgFace.mFaceRect[5]; //人眼睁的具体值
            //AgFace.mFaceStates[11] > 80  亮度
            //抓怕条件，正脸，人睁眼最大，亮度满足条件

            //Log.d("FaceDetect","nRvalue "+Integer.toString(nR));
            //AgFace.mFaceStates[11] 代表图像亮度

            //因为手机获取的图像是会有旋转的
            //AgFace.mFaceStates[6] 代表实际的图像需要旋转多少度，才能是正的图像

            boolean bOkAngle = false;
            if(nR <= 12)
            {
                bOkAngle = true;
                //如果角度小于一定的值，都可以认为值得保存
            }
            if(minR > nR)
            {
                //如果角度比之前的小，都可以认为值得保存
                minR = nR;
                bOkAngle = true;
            }


            boolean bEyeDisOk =false;
            if(maxDisEye< fDisEye)
            {
                maxDisEye =fDisEye;
                bEyeDisOk = true;
            }

            Log.i("MYINFO", "eyedis value is ************************************* "+String.valueOf(fDisEye) + " "+String.valueOf(maxDisEye));

            if(AgFace.mFaceStates[9] == 1)
            {
                mRealCount ++;
            }
            else
            {
                mRealCount = 0;
            }

            if( mRealCount >=4 )
            {
                if(AgFace.mFaceStates[6] == 1 )
                {
                    //保存的条件 人脸旋转角度最小; 睁眼状态; 亮度大于80
                    if(bOkAngle && bEyeDisOk && AgFace.mFaceStates[11] > 80)
                    {
                        //逆时针90
                        mNewSaveBitmap = rotateBitmap(mBitmap,-90);
                    }
                    if(mNewSaveBitmap == null)
                    {
                        mNewSaveBitmap = rotateBitmap(mBitmap,-90);
                    }

                }
                else if(AgFace.mFaceStates[6] == 2)
                {

                    if(bOkAngle && bEyeDisOk && AgFace.mFaceStates[11] > 80) {

                        mNewSaveBitmap = rotateBitmap(mBitmap, 90);
                    }
                    if(mNewSaveBitmap == null)
                    {
                        mNewSaveBitmap = rotateBitmap(mBitmap,90);
                    }
                }
                else if(AgFace.mFaceStates[6] == 3 )
                {
                    if(bOkAngle && bEyeDisOk && AgFace.mFaceStates[11] > 80) {

                        mNewSaveBitmap = rotateBitmap(mBitmap, 180);
                    }

                    if(mNewSaveBitmap == null)
                    {
                        mNewSaveBitmap = rotateBitmap(mBitmap,180);
                    }
                }
                else
                {

                    if(bOkAngle && bEyeDisOk && AgFace.mFaceStates[11] > 80) {

                        mNewSaveBitmap = mBitmap;
                    }

                    if(mNewSaveBitmap == null)
                    {
                        mNewSaveBitmap =mBitmap;
                    }
                }
            }

        }


    }

     public String StopCamera(boolean bSuccess)
     {
         if (mCamera != null) {
             mCamera.stopPreview();
         }
         //保存当前的图片
         if(mNewSaveBitmap != null)
         {
            // String pathname = android.os.Environment.getExternalStorageDirectory().getAbsolutePath();
           //  String filename ="/test.jpg";//我的华为手机文件存放在 Download路径下
           //  saveImage(mNewSaveBitmap,filename);

             byte[] outjpgbyte = getBitmapByte(mNewSaveBitmap);
             String base64 = ImageBase64Converter.convertByteToBase64(outjpgbyte);
             AgFace.SetCapStrBase64(base64);
             this.finish();
            return base64;
         }
         this.finish();
          return "";
     }
    public byte[] getBitmapByte(Bitmap bitmap){
                 ByteArrayOutputStream out = new ByteArrayOutputStream();
                bitmap.compress(Bitmap.CompressFormat.JPEG, 90, out);
                 try {
                        out.flush();
                         out.close();
                     } catch (IOException e) {
                         e.printStackTrace();
                     }
                return out.toByteArray();
    }
    /**
     * Releases the resources associated with the camera source, the associated detector, and the
     * rest of the processing pipeline.
     */
    @Override
    protected void onDestroy() {
        super.onDestroy();

    }


    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putInt(BUNDLE_CAMERA_ID, cameraId);
    }

    @Override
    public void surfaceCreated(SurfaceHolder surfaceHolder) {


        //Find the total number of cameras available
        numberOfCameras = Camera.getNumberOfCameras();
        Camera.CameraInfo cameraInfo = new Camera.CameraInfo();
        for (int i = 0; i < Camera.getNumberOfCameras(); i++) {
            Camera.getCameraInfo(i, cameraInfo);
            if (cameraInfo.facing == Camera.CameraInfo.CAMERA_FACING_BACK)
            {
               // if (cameraId == 1) cameraId = i;
            }
        }

        mCamera = Camera.open(cameraId);

        Camera.getCameraInfo(cameraId, cameraInfo);
        if (cameraInfo.facing == Camera.CameraInfo.CAMERA_FACING_FRONT) {
            mFaceView.setFront(true);
        }
        else
        {
            mFaceView.setFront(false);
        }
        try {
            mCamera.setPreviewDisplay(mView.getHolder());
        } catch (Exception e) {
            Log.e(TAG, "Could not preview the image.", e);
        }
    }

    @Override
    public void surfaceChanged(SurfaceHolder surfaceHolder, int format, int width, int height) {
        // We have no surface, return immediately:
        if (surfaceHolder.getSurface() == null) {
            return;
        }
        // Try to stop the current preview:
        try {
            mCamera.stopPreview();
        } catch (Exception e) {
            // Ignore...
        }

        configureCamera(width, height);
        setDisplayOrientation();
        setErrorCallback();

        // Create media.FaceDetector
        float aspect = (float) previewHeight / (float) previewWidth;

        // Everything is configured! Finally start the camera preview again:
        startPreview();
    }

    private void setErrorCallback() {
        mCamera.setErrorCallback(mErrorCallback);
    }

    private void setDisplayOrientation() {
        // Now set the display orientation:
        mDisplayRotation = Util.getDisplayRotation(FaceDetectRGBActivity.this);
        mDisplayOrientation = Util.getDisplayOrientation(mDisplayRotation, cameraId);

        mCamera.setDisplayOrientation(mDisplayOrientation);

        if (mFaceView != null) {
            mFaceView.setDisplayOrientation(mDisplayOrientation);
        }
    }

    private void configureCamera(int width, int height) {
        Camera.Parameters parameters = mCamera.getParameters();
        parameters.setPreviewFormat(ImageFormat.NV21);
        // Set the PreviewSize and AutoFocus:
        setOptimalPreviewSize(parameters, width, height);
        //setAutoFocus(parameters);
        // And set the parameters:
        mCamera.setParameters(parameters);
    }

    private void setOptimalPreviewSize(Camera.Parameters cameraParameters, int width, int height) {
        List<Camera.Size> previewSizes = cameraParameters.getSupportedPreviewSizes();
        float targetRatio = (float) width / height;
        Camera.Size previewSize = Util.getOptimalPreviewSize(this, previewSizes, targetRatio);
        previewWidth = previewSize.width;
        previewHeight = previewSize.height;

        Log.e(TAG, "previewWidth" + previewWidth);
        Log.e(TAG, "previewHeight" + previewHeight);

        /**
         * Calculate size to scale full frame bitmap to smaller bitmap
         * Detect face in scaled bitmap have high performance than full bitmap.
         * The smaller image size -> detect faster, but distance to detect face shorter,
         * so calculate the size follow your purpose
         */
          if (previewWidth > 640) {
            prevSettingWidth = 640;
            prevSettingHeight = 480;
        } else if (previewWidth  > 720) {
            prevSettingWidth = 720;
            prevSettingHeight = 540;
        }else if (previewWidth / 4 > 240) {
            prevSettingWidth = 240;
            prevSettingHeight = 160;
        } else {
            prevSettingWidth = 160;
            prevSettingHeight = 120;
        }

        cameraParameters.setPreviewSize(previewSize.width, previewSize.height);

        mFaceView.setPreviewWidth(previewWidth);
        mFaceView.setPreviewHeight(previewHeight);
    }

    private void setAutoFocus(Camera.Parameters cameraParameters) {
        List<String> focusModes = cameraParameters.getSupportedFocusModes();
        if (focusModes.contains(Camera.Parameters.FOCUS_MODE_CONTINUOUS_PICTURE))
            cameraParameters.setFocusMode(Camera.Parameters.FOCUS_MODE_CONTINUOUS_PICTURE);
    }

    private void startPreview() {
        if (mCamera != null) {
            isThreadWorking = false;
            mCamera.startPreview();
            mCamera.setPreviewCallback(this);

        }
    }


    @Override
    public void surfaceDestroyed(SurfaceHolder surfaceHolder) {
        mCamera.setPreviewCallbackWithBuffer(null);
        mCamera.setErrorCallback(null);
        mCamera.release();
        mCamera = null;
    }


    @Override
    public void onPreviewFrame(byte[] _data, Camera _camera) {
        if (!isThreadWorking) {

            isThreadWorking = true;
            waitForFdetThreadComplete();
            detectThread = new FaceDetectThread(handler, this);
            detectThread.setData(_data);
            detectThread.start();
        }
    }
    /**
     * 选择变换
     *
     * @param origin 原图
     * @param alpha  旋转角度，可正可负
     * @return 旋转后的图片
     */
    private Bitmap rotateBitmap(Bitmap origin, float alpha) {

        int width = origin.getWidth();
        int height = origin.getHeight();
        Matrix matrix = new Matrix();
        matrix.setRotate(alpha);
        // 围绕原地进行旋转
        Bitmap newBM = Bitmap.createBitmap(origin, 0, 0, width, height, matrix, false);
        if (newBM.equals(origin)) {
            return newBM;
        }

        return newBM;
    }
    public static void saveImage(Bitmap bmp,  String fileName )
    {

        File appDir = new File(Environment.getExternalStorageDirectory(), "Download");
        if (!appDir.exists()) {
            appDir.mkdir();
        }


        File file = new File(appDir, fileName);
        Log.e("myerror",appDir.toString()+"***************");
        try {
            FileOutputStream fos = new FileOutputStream(file);
            bmp.compress(Bitmap.CompressFormat.JPEG, 100, fos);
            fos.flush();
            fos.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

    }

    private void waitForFdetThreadComplete() {
        if (detectThread == null) {
            return;
        }

        if (detectThread.isAlive()) {
            try {
                detectThread.join();
                detectThread = null;
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }

    }





    /**
     * Do face detect in thread
     */
    private class FaceDetectThread extends Thread {
        private Handler handler;
        private byte[] data = null;
        private Context ctx;
        private Bitmap faceCroped;

        public FaceDetectThread(Handler handler, Context ctx) {
            this.ctx = ctx;
            this.handler = handler;
        }


        public void setData(byte[] data) {
            this.data = data;
        }

        public void run() {
//            Log.i("FaceDetectThread", "running");



            float aspect = (float) previewHeight / (float) previewWidth;


            // mBitmap.getPixels(mbyteDataCp, 0, previewWidth, 0, 0, previewWidth, previewHeight);
            //int iCount=AgFace.FaceTraceRGBA8888(mbyteDataCp, previewWidth, previewHeight,mFaceStates, mFaceRect,mFaceMarks);

            int iCount = AgFace.FaceTraceNv12Short(data, previewWidth, previewHeight);
            if(iCount == 0)
            {
                face.setFace(0,AgFace.mFaceRect,AgFace.mFaceMarks,AgFace.mFaceStates);
            }
            else
            {
                face.setFace(1,AgFace.mFaceRect,AgFace.mFaceMarks,AgFace.mFaceStates);
                CapToBitmap(data);
            }
            /*   Bitmap bitmap = Bitmap.createBitmap(previewWidth, previewHeight, Bitmap.Config.RGB_565);
            // face detection: first convert the image from NV21 to RGB_565
            YuvImage yuv = new YuvImage(data, ImageFormat.NV21,
                    bitmap.getWidth(), bitmap.getHeight(), null);
            // TODO: make rect a member and use it for width and height values above
            Rect rectImage = new Rect(0, 0, bitmap.getWidth(), bitmap.getHeight());

*/
            handler.post(new Runnable()
            {
                public void run() {
                    //send face to FaceView to draw rect
                    mFaceView.setFace(face);

                    isThreadWorking = false;
                }
            });
        }
    }




}
