// Copyright (c) Philipp Wagner. All rights reserved.
// Licensed under the MIT license. See LICENSE file in the project root for full license information.

package m.tri.facedetectcamera.activity.ui;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.RectF;
import android.util.DisplayMetrics;
import android.util.TypedValue;
import android.view.View;

import com.Agile.AgFace;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.Calendar;
import java.util.Random;
import java.util.Timer;
import java.util.TimerTask;

import dev.mars.openslesdemo.OpenSLPlayer;
import m.tri.facedetectcamera.activity.FaceDetectRGBActivity;
import m.tri.facedetectcamera.model.FaceResult;

/**
 * Created by Nguyen on 5/20/2016.
 */

/**
 * This class is a simple View to display the faces.
 */
public class FaceOverlayView extends View {

    private Paint mPaint;
    private Paint mTextPaint;
    private int mDisplayOrientation;
    private int mOrientation;
    private int previewWidth;
    private int previewHeight;

    private FaceResult mFace;
    private boolean isFront = false;

    private  int mIAntiCount = 0;

    int mRand0 = 0;
    int mRand1 = 0;


    private OpenSLPlayer player;
    private Rect mMarkRect;
    Bitmap bitmapMark;
    boolean mBTimeOut = false;
    Timer timer = null;

    public FaceOverlayView(Context context) {
        super(context);
        initialize();
    }

    private void GenerateRand() {
        Calendar cal = Calendar.getInstance();
        Random r = new Random(cal.get(Calendar.SECOND));
        mRand0 = (r.nextInt() % 100 + 100) % 3;
        mRand1 = (r.nextInt() % 100 + 100) % 2;

    }

    private void initialize() {
        // We want a green box around the face:
        DisplayMetrics metrics = getResources().getDisplayMetrics();

        int stroke = (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, 2, metrics);
        mPaint = new Paint();
        mPaint.setAntiAlias(true);
        mPaint.setDither(true);
        mPaint.setColor(Color.GREEN);
        mPaint.setStrokeWidth(stroke);
        mPaint.setStyle(Paint.Style.STROKE);

        mTextPaint = new Paint();
        mTextPaint.setAntiAlias(true);
        mTextPaint.setDither(true);
        int size = (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, 25, metrics);
        mTextPaint.setTextSize(size);
        mTextPaint.setColor(Color.GREEN);
        mTextPaint.setStyle(Paint.Style.FILL);
        mTextPaint.setTextAlign(Paint.Align.CENTER);
        player = new OpenSLPlayer();
        try {

            FileInputStream fis = new FileInputStream(android.os.Environment.getExternalStorageDirectory().getAbsolutePath() + "/model_smallface/mark.png");
            bitmapMark = BitmapFactory.decodeStream(fis);
            mMarkRect = new Rect(0, 0, bitmapMark.getWidth(), bitmapMark.getHeight());
        } catch (FileNotFoundException e) {

            e.printStackTrace();

        }

        //定时器限制时长
        StartTimer();

        //随机生成需要做的动作
        GenerateRand();

    }

    private void StartTimer() {
        // 初始化定时器 20000超时20秒，此值也可以自己设置
        timer = new Timer();
        timer.schedule(new TimerTask() {

            @Override
            public void run() {
                mBTimeOut = true;
                stopTimer();
            }
        }, 20000, 1);


    }

    //停止定时器
    private void stopTimer() {
        if (timer != null) {
            timer.cancel();
            timer = null;
        }
    }

    public void setFace(FaceResult face) {
        mFace = face;
        invalidate();

    }

    public void setOrientation(int orientation) {
        mOrientation = orientation;
    }

    public void setDisplayOrientation(int displayOrientation) {
        mDisplayOrientation = displayOrientation;
        invalidate();
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        if (mFace != null) {

            float scaleX = (float) getWidth() / (float) previewWidth;
            float scaleY = (float) getHeight() / (float) previewHeight;

            switch (mDisplayOrientation) {
                case 90:
                case 270:
                    scaleX = (float) getWidth() / (float) previewHeight;
                    scaleY = (float) getHeight() / (float) previewWidth;
                    break;
            }


            canvas.save();
            canvas.rotate(-mOrientation);

            //绘制人脸限制框的贴图
            canvas.drawBitmap(bitmapMark, mMarkRect, new RectF(0, 0, getWidth(), getHeight()), mPaint);

            if (mFace.getId() != 0) {

                //人脸区域判断
                if(!TestAnddrawFaceRect(canvas))
                {
                    RectF rectF=new RectF(0, 0, getWidth(), getHeight());
                    canvas.drawText("请人脸在人像区域！！", rectF.centerX(), previewHeight*0.2f, mTextPaint);
                }
                else
                {
                    //进行命令通过
                    procInstructionTest(canvas);
                }

            }
            canvas.restore();
        }


    }
    // 画人脸框，仅仅测试用
    private Boolean TestAnddrawFaceRect(Canvas canvas)
    {
        RectF rectF = new RectF();

        rectF.set(new RectF(mFace.mRect[0] * getWidth(), mFace.mRect[1] * getHeight(), mFace.mRect[2] * getWidth(), mFace.mRect[3] * getHeight()));

        //android java 界面显示画面和 底层返回的数据是否存在水平差异调整；不同手机不一样的效果，
        //暂时采用下面办法显示，不过不同手机不能统一，建议去掉人脸框显示
        if (isFront) {
            float left = rectF.left;
            float right = rectF.right;
            rectF.left = getWidth() - right;
            rectF.right = getWidth() - left;
        }




        //canvas.drawRect(rectF, mPaint);
        canvas.drawLine(rectF.left, rectF.top, rectF.left + rectF.width() * 0.2f, rectF.top, mPaint);
        canvas.drawLine(rectF.left, rectF.top, rectF.left, rectF.top + rectF.height() * 0.2f, mPaint);

        canvas.drawLine(rectF.left + rectF.width() * 0.8f, rectF.top, rectF.left + rectF.width(), rectF.top, mPaint);
        canvas.drawLine(rectF.left + rectF.width(), rectF.top, rectF.left + rectF.width(), rectF.top + rectF.height() * 0.2f, mPaint);


        canvas.drawLine(rectF.left, rectF.top + rectF.height(), rectF.left + rectF.width() * 0.2f, rectF.top + rectF.height(), mPaint);
        canvas.drawLine(rectF.left, rectF.top + rectF.height() * 0.8f, rectF.left, rectF.top + rectF.height(), mPaint);


        canvas.drawLine(rectF.left + rectF.width() * 0.8f, rectF.top + rectF.height(), rectF.left + rectF.width(), rectF.top + rectF.height(), mPaint);
        canvas.drawLine(rectF.left + rectF.width(), rectF.top + rectF.height() * 0.8f, rectF.left + rectF.width(), rectF.top + rectF.height(), mPaint);

        float centX = (rectF.left+rectF.right)/2;
        float centY = (rectF.top+ rectF.bottom)/2;
        if(centX/getWidth() > 0.6
         ||       centX/getWidth() < 0.3
                ||  centY/getHeight() > 0.75
             ||   centY/getHeight() < 0.3
        || centY/getHeight() >0.6)
        {
            return false;
        }

        return true;
    }

    //逻辑判断+提示说明
    private void procInstructionTest(Canvas canvas)
    {
        RectF rectF=new RectF(0, 0, getWidth(), getHeight());


        if(mFace.mFaceState[9] == 0)
        {
            mIAntiCount++;
            if(mIAntiCount > 10)
            {
                canvas.drawText("非真人攻击", rectF.centerX(), previewHeight*0.2f, mTextPaint);
                AgFace.SetFailedInfo("非真人攻击");
                FaceDetectRGBActivity.gSFaceActivity.StopCamera(false);
            }
        }
        else {
            mIAntiCount=0;
        }


        if(mBTimeOut)
        {
            AgFace.SetFailedInfo("超时");
            canvas.drawText("验证没有通过，超时！！", rectF.centerX(), previewHeight*0.2f, mTextPaint);
            FaceDetectRGBActivity.gSFaceActivity.StopCamera(false);
            return;
        }


       

       /* if(mFace.mFaceState[10] == 1)
            canvas.drawText("带口罩了！！", rectF.centerX(), previewHeight*0.08f, mTextPaint);
        else
        {
            canvas.drawText("没有带口罩！！", rectF.centerX(), previewHeight*0.08f, mTextPaint);
        }*/

       if(mRand0 !=  -1)
        {
            switch (mRand0)
            {
                case 0:
                    //因为有的摄像头做了水平镜像，所以无法明确向左还是向右，所以向左和向右统一为一个动作
                    canvas.drawText("请左转或者右转", rectF.centerX(), previewHeight*0.2f, mTextPaint);
                    if(mFace.mFaceState[0] == 1 || mFace.mFaceState[1] == 1)
                    {
                        mRand0 = -1;
                    }
                    break;
                case 1:
                    canvas.drawText("请抬头", rectF.centerX(), previewHeight * 0.2f, mTextPaint);
                    if (mFace.mFaceState[2] == 1) {
                        mRand0 = -1;
                    }
                    break;
                case 2:

                    canvas.drawText("请低头", rectF.centerX(), previewHeight*0.2f, mTextPaint);
                    if(mFace.mFaceState[3] == 1) {
                        mRand0 = -1;
                    }
                    break;
                default:
                    break;
            }
        }


        if(mRand0 == -1 && mRand1 != -1)
        {
            //正对摄像头的判断
            //做张嘴眨眼动作
            if(mFace.mFaceState[0] == 0
             && mFace.mFaceState[1] == 0
                    && mFace.mFaceState[2] == 0
                    && mFace.mFaceState[3] == 0)
            {
                switch (mRand1)
                {
                    case 0:

                        if(mFace.mFaceState[4] == 1) {
                            mRand1 = -1;
                            FaceDetectRGBActivity.gSFaceActivity.mBneedCap =false;

                        }
                        if(mRand1 != -1)
                            canvas.drawText("请张嘴", rectF.centerX(), previewHeight*0.23f, mTextPaint);
                        //张嘴的情况下不用抓拍

                        break;
                    case 1:

                        if(mFace.mFaceState[5] == 1) {
                            mRand1 = -1;
                            FaceDetectRGBActivity.gSFaceActivity.mBneedCap =false;
                        }
                        if(mRand1 != -1)
                            canvas.drawText("请眨眼", rectF.centerX(), previewHeight*0.23f, mTextPaint);
                        //张嘴的情况下不用抓拍
                        break;
                    default:
                        break;
                }

            }
            else
            {
                canvas.drawText("请正对摄像头", rectF.centerX(), previewHeight*0.23f, mTextPaint);
            }




            }



        //两个动作完毕
        if(mRand1 == -1 && mRand0 == -1)
       {
           canvas.drawText("          ", rectF.centerX(), previewHeight*0.23f, mTextPaint);


            if(mFace.mFaceState[9] == 1)//
            {
                canvas.drawText("通过", rectF.centerX()*1.2f, previewHeight*0.275f, mTextPaint);

                //增加亮度输出的原因是，摄像头刚启动的时候，可能抓拍的图像偏暗(光线没有进入)
                canvas.drawText("活体(静默)分"+Float.toString(AgFace.mFaceRect[4])+" 亮"+ Integer.toString(AgFace.mFaceStates[11]), rectF.centerX()*1.2f, previewHeight*0.2f, mTextPaint);
                //验证成功，停止摄像头
                AgFace.SetFaceReal(true);
                AgFace.SetFailedInfo("成功");
                FaceDetectRGBActivity.gSFaceActivity.StopCamera(true);


            }
            else
            {
                canvas.drawText("没通过", rectF.centerX()*1.2f, previewHeight*0.275f, mTextPaint);
                canvas.drawText("非活体(静默)分"+Float.toString(AgFace.mFaceRect[4]), rectF.centerX()*1.2f, previewHeight*0.2f, mTextPaint);
                //验证成功，停止摄像头
                AgFace.SetFailedInfo("非真人");
                FaceDetectRGBActivity.gSFaceActivity.StopCamera(false);

            }

            stopTimer();//停止定时器

            //抓拍的图像
            if(FaceDetectRGBActivity.gSFaceActivity.mNewSaveBitmap != null)
           {
               Rect tR  = new Rect(0,0,
                       FaceDetectRGBActivity.gSFaceActivity.mNewSaveBitmap.getWidth(),
                       FaceDetectRGBActivity.gSFaceActivity.mNewSaveBitmap.getHeight());
               canvas.drawBitmap(FaceDetectRGBActivity.gSFaceActivity.mNewSaveBitmap, tR, new RectF(0, 0, getWidth()*0.2f, getHeight()*0.2f), mPaint);
           }

        }



    }

    public void setPreviewWidth(int previewWidth) {
        this.previewWidth = previewWidth;
    }

    public void setPreviewHeight(int previewHeight) {
        this.previewHeight = previewHeight;
    }

    public void setFront(boolean front) {
        isFront = front;
    }
}