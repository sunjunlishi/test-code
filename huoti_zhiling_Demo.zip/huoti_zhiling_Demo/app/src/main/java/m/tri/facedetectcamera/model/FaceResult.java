package m.tri.facedetectcamera.model;

import android.graphics.PointF;

/**
 * Created by sunjunli on 11/20/2018.
 */

public class FaceResult extends Object {

    public float [] mRect;
    public float[] mMarks;
    public int[] mFaceState;
    private int mHasFace;


    public FaceResult() {
        mHasFace = 0;
        mRect = new float[5];
        mFaceState = new int[12];

    }


    public void setFace(int iHasFace,float[] faceRect,float[] marks,int[] faceState) {
        set(iHasFace, faceRect,marks,faceState);
    }

    public void clear() {
        set(0, mRect,mMarks,mFaceState);
    }

    public synchronized void set(int iHasFace, float[] faceRect,float[] marks,int [] faceState) {
        this.mHasFace = iHasFace;


        this.mRect = faceRect;
        this.mMarks = marks;
        this.mFaceState = faceState;


    }


    public int getId() {
        return mHasFace;
    }

    public void setId(int id) {
        this.mHasFace = id;
    }


}
