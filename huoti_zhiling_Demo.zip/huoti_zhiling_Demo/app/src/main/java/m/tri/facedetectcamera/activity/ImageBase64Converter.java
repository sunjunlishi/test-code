
package m.tri.facedetectcamera.activity;
import java.io.*;



public class ImageBase64Converter {
    /**
     * 本地文件（图片、excel等）转换成Base64字符串
     *
     * @param imgPath
     */
    public static String convertFileToBase64(String imgPath) {
        byte[] data = null;
        // 读取图片字节数组
        try {
            InputStream in = new FileInputStream(imgPath);
            System.out.println("文件大小（字节）="+in.available());
            data = new byte[in.available()];
            in.read(data);
            in.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        // 对字节数组进行Base64编码，得到Base64编码的字符串

        String base64Str = Base64Encoder.encode(data);
        return base64Str;
    }

    public static String convertByteToBase64(byte[] data) {

        // 对字节数组进行Base64编码，得到Base64编码的字符串

        String base64Str = Base64Encoder.encode(data);
        return base64Str;
    }

}